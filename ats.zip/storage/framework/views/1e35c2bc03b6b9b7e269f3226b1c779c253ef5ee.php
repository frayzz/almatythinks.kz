<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <!-- Sidebar -->
    <div class="sidebar">
        <ul class="pt-3 nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
                 with font-awesome or any other icon font library -->
            <li class="nav-item">
                <a href="<?php echo e(route('personal.main.index')); ?>" class="nav-link">
                    <i class="nav-icon fas fa-home"></i>
                    <p>
                        Главная страница
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('personal.liked.index')); ?>" class="nav-link">
                    <i class="nav-icon far fa-heart"></i>
                    <p>
                        Понравившиеся
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('personal.comment.index')); ?>" class="nav-link">
                    <i class="nav-icon far fa-comment"></i>
                    <p>
                        Комментарий
                    </p>
                </a>
            </li>
        </ul>
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /var/www/vhosts/almatythinks.kz/httpdocs/resources/views/personal/includes/sidebar.blade.php ENDPATH**/ ?>