<?php $__env->startSection('content'); ?>
    <main class="blog">
        <div class="container">
            <form action="<?php echo e(route('admin.post.store')); ?>" method="POST">
                <div class="form-group">
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="10" style="border: 1px solid #d3d3d3"
                          name="content"><?php echo e(old('content')); ?></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">Это поле необходимо для заполнения <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Отправить">
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/almatythinks.kz/httpdocs/resources/views/main/create.blade.php ENDPATH**/ ?>