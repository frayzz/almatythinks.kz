<div class="flex justify-center max-w-5xl min-h-screen pb-16 mx-auto">
    <div class="leading-none text-center text-black md:text-left">
        <h1 class="mb-2 text-5xl font-extrabold"><?php echo e($errorCode); ?></h1>
        <p class="text-xl text-gray-900">
            <?php if(isset($title)): ?>
                <?php echo e($title); ?>

            <?php else: ?>
                Hello, is it me you're looking for?
            <?php endif; ?>

            <?php if($homeLink ?? false): ?>
                <a href="<?php echo e(url('/')); ?>" class="font-bold underline transition duration-300 hover:text-blue-600">Go home</a>
            <?php endif; ?>
        </p>
    </div>
</div>
<?php echo $__env->make('front.layouts.errors', [
    'title' => 'Be right back',
    'errorCode' => '503',
    'homeLink' => false,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/jalda.kz/almatythinks.kz/resources/views/errors/503.blade.php ENDPATH**/ ?>