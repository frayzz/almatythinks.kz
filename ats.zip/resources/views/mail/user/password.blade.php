@component('mail::message')
Ваш пароль: {{ $password }}
@endcomponent
